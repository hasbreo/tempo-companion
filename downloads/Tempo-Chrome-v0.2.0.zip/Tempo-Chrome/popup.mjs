const $=id=>document.getElementById(id),fmt=n=>{n=Math.floor(Math.max(0,n||0));return n>=3600?Math.floor(n/3600)+':'+String(Math.floor(n%3600/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0'):Math.floor(n/60)+':'+String(n%60).padStart(2,'0');};
let state=null,busy=false,coverKey='';
function error(text){$('error').hidden=!text;$('error').textContent=text||'';}
async function send(type,args){const result=await chrome.runtime.sendMessage({target:'tempo-popup',type,args});if(result?.error)throw Error(result.error);if(result?.state){state=result.state;render();}return result;}
function render(){
  if(!state)return;
  $('waiting').hidden=true;$('signed-out').hidden=state.connected;$('player').hidden=!state.connected||!state.book;$('no-book').hidden=!state.connected||!!state.book;
  if(!state.book)return;
  const b=state.book,ch=state.chapter||{start:0,end:b.duration,title:'Audiobook'};
  $('title').textContent=b.title;$('author').textContent=b.author;$('series').textContent=b.series||'';
  const nextCover=b.id+'|'+(state.cover||'');if(nextCover!==coverKey){coverKey=nextCover;$('cover').replaceChildren();if(state.cover){const image=document.createElement('img');image.src=state.cover;image.alt='';$('cover').append(image);}else $('cover').textContent=b.title.split(/\s+/).slice(0,2).map(s=>s[0]).join('');}
  $('chapter').textContent=ch.title;$('chapter').title=ch.title;$('chapter-time').textContent=fmt(state.position-ch.start)+' / '+fmt(ch.end-ch.start);
  if(document.activeElement!==$('seek')){$('seek').min=ch.start;$('seek').max=ch.end;$('seek').value=state.position;}
  $('book-time').textContent=fmt(state.position)+' / '+fmt(b.duration)+' in book';$('play').textContent=state.paused?'▶':'Ⅱ';$('play').setAttribute('aria-label',state.paused?'Play':'Pause');
  if(![...$('speed').options].some(o=>Number(o.value)===state.speed)){const option=document.createElement('option');option.value=state.speed;option.textContent=state.speed+'×';$('speed').append(option);}$('speed').value=String(state.speed);
  $('status').textContent=state.phase||state.problem||state.sync||'Tempo Web';
}
async function act(type,args){if(busy)return;busy=true;error('');for(const id of ['play','back','forward','refresh'])$(id).disabled=true;try{await send(type,args);}catch(e){error(e.message);}finally{busy=false;for(const id of ['play','back','forward','refresh'])$(id).disabled=false;}}
const open=event=>{event?.preventDefault();send('openWeb').then(()=>window.close()).catch(e=>error(e.message));};
$('open-web').onclick=open;$('full-web').onclick=open;$('sign-in').onclick=open;
$('play').onclick=()=>act('toggle');$('back').onclick=()=>act('skip',{seconds:-30});$('forward').onclick=()=>act('skip',{seconds:30});$('refresh').onclick=()=>act('refresh');
$('seek').onchange=event=>act('seek',{position:Number(event.target.value)});$('speed').onchange=event=>act('speed',{value:Number(event.target.value)});
send('cached').catch(()=>{}).finally(()=>act('refresh'));
setInterval(()=>{if(!busy&&!document.hidden)send('state').catch(e=>error(e.message));},1000);
