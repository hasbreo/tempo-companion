const WEB='https://tempo.hasbreo.com',peers=new Map(),requests=new Map();
let selected=null,creating,cached=null,lastPopupPing=Date.now(),closing=false;
// Retire the old standalone login without discarding its unsent progress.
const migrated=(async()=>{
  const legacy=(await chrome.storage.local.get('tempo')).tempo;
  if(legacy?.auth)await chrome.storage.local.set({tempo:{...legacy,auth:null,remember:false}});
  await chrome.storage.session.remove('auth');
})();
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function permitted(sender){try{return sender.id===chrome.runtime.id&&new URL(sender.url).origin===WEB;}catch{return false;}}
function pick(){
  const ready=[...peers.values()].filter(p=>p.state);
  return ready.find(p=>p.state.connected&&!p.state.paused)||
    ready.find(p=>p.id===selected&&p.state.connected)||
    ready.find(p=>p.tabId!==null&&p.state.connected)||
    ready.find(p=>p.state.connected)||ready.find(p=>p.tabId!==null)||ready[0]||null;
}
async function hasPlayer(){return (await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[chrome.runtime.getURL('offscreen.html')]})).length>0;}
async function ensurePlayer(){
  if(await hasPlayer())return;
  if(!creating)creating=chrome.offscreen.createDocument({url:'offscreen.html',reasons:['AUDIO_PLAYBACK','IFRAME_SCRIPTING'],justification:'Host the existing Tempo Web player and relay playback controls while its visible tab and the toolbar popup are closed.'}).finally(()=>{creating=null;});
  await creating;
}
async function peer(){
  let p=pick();if(p?.state.connected)return p;
  await ensurePlayer();
  for(let i=0;i<150;i++){
    p=pick();if(p?.state.connected)return p;
    const background=[...peers.values()].find(p=>p.tabId===null&&p.state);
    if(background)return background;
    await wait(200);
  }
  if(p)return p;
  throw Error('Tempo Web is taking a while to connect. Open it once, then try again.');
}
async function command(p,name,args={}){
  const id=crypto.randomUUID();
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{requests.delete(id);reject(Error('Tempo Web took too long to respond. Try again.'));},45000);
    requests.set(id,{peer:p.id,resolve,reject,timer});
    try{p.port.postMessage({type:'command',id,command:name,args});}catch(error){clearTimeout(timer);requests.delete(id);reject(error);}
  });
}
async function remember(state){
  cached=state;
  // Only enough non-secret information to continue after a visible Web tab closes.
  await chrome.storage.session.set({continuation:{id:state.book?.id||null,position:state.position||0,playing:!state.paused,at:Date.now()}});
}
async function handoff(last){
  if(!last?.book||last.paused)return;
  try{
    await ensurePlayer();
    let p;
    for(let i=0;i<150;i++){p=[...peers.values()].find(p=>p.tabId===null&&p.state);if(p)break;await wait(200);}
    if(p?.state.connected){selected=p.id;await command(p,'handoff',{id:last.book.id,position:last.position});}
  }catch{}
}
chrome.runtime.onConnect.addListener(port=>{
  if(port.name!=='tempo-web'||!permitted(port.sender))return;
  const id=crypto.randomUUID(),p={id,port,tabId:port.sender.tab?.id??null,state:null};peers.set(id,p);
  port.onMessage.addListener(message=>{
    if(message.type==='state'&&message.state){
      p.state=message.state;
      if(pick()?.id===id){selected=id;remember(p.state).catch(()=>{});}
      if(p.tabId===null&&p.state.paused&&Date.now()-lastPopupPing>30000&&!closing){closing=true;chrome.offscreen.closeDocument().catch(()=>{}).finally(()=>{closing=false;});}
    }
    if(message.type==='reply'){
      const r=requests.get(message.id);if(!r||r.peer!==id)return;
      clearTimeout(r.timer);requests.delete(message.id);
      if(message.state){p.state=message.state;if(pick()?.id===id)remember(p.state).catch(()=>{});}
      message.error?r.reject(Error(message.error)):r.resolve(message.state);
    }
  });
  port.onDisconnect.addListener(()=>{
    peers.delete(id);
    for(const [requestId,r]of requests)if(r.peer===id){clearTimeout(r.timer);r.reject(Error('Tempo Web reconnected. Try once more.'));requests.delete(requestId);}
    if(selected===id){selected=null;if(p.tabId!==null)handoff(p.state);}
  });
});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.target!=='tempo-popup'||sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('popup.html'))return;
  lastPopupPing=Date.now();
  const run=async()=>{
    await migrated;
    if(message.type==='openWeb'){await chrome.tabs.create({url:WEB});return {ok:true};}
    if(message.type==='cached')return {ok:true,state:pick()?.state||cached};
    const p=await peer();selected=p.id;
    if(message.type==='state')return {ok:true,state:await command(p,'state')};
    if(!['refresh','toggle','skip','seek','speed'].includes(message.type))throw Error('Unsupported player action.');
    return {ok:true,state:await command(p,message.type,message.args)};
  };
  run().then(reply,error=>reply({error:error.message}));return true;
});
