// Reload is used only to recover the hosted Tempo Web connection, not to sign in.
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.target!=='tempo-offscreen'||message.type!=='reload')return;
  document.getElementById('tempo').src='https://tempo.hasbreo.com/now-playing?chrome_companion=1';reply({ok:true});
});
