TEMPO FOR CHROME — 0.2.0
A small, normal Chrome toolbar popup for Tempo Web.

INSTALL OR UPDATE
1. Extract this ZIP. Keep the Tempo-Chrome folder somewhere permanent.
2. For an update: stop playback and replace the contents of the existing
   installed Tempo-Chrome folder with this folder's files. Open
   chrome://extensions and click Reload on Tempo.
   For a new install: enable Developer mode, choose Load unpacked and
   select the Tempo-Chrome folder containing manifest.json.
3. Pin Tempo — Web Player Companion using Chrome's Extensions menu.
4. Open https://tempo.hasbreo.com in this SAME Chrome profile, refresh it,
   and sign in there. Enable Tempo Web's Remember login if you want to
   listen with its visible tab closed. There is no extension login.
5. Click the pinned Tempo icon. The native popup controls Tempo Web's
   latest unfinished continue-listening book. Choose another book in Web.

PLAYBACK
Play/pause, skip 30 seconds, chapter scrub and playback speed.
Click outside the popup to close it; audio continues while Chrome runs.
With a remembered Web login, the extension can host the existing Tempo
Web player invisibly when its visible tab is closed. Internet is needed.
Closing Chrome stops playback. Reopen the popup to resume.

SIGN-IN
Only the remembered login at https://tempo.hasbreo.com is shared.
A different hostname, another Chrome profile, or a session-only login
will not supply a saved login to the background Web player. With a
session-only login, keep the signed-in Tempo Web tab open.
If prompted, choose Open Tempo Web, sign in there, then try again.
Position conflicts are resolved in Tempo Web.

DESIGN & PERMISSIONS
A compact 350px emerald-and-mint glass-style toolbar popup. Chrome's
native popup does not blur the actual webpage behind it.
Offscreen hosts Tempo Web; storage retains a nonsecret continuation;
access to tempo.hasbreo.com connects the Web player. No access to the
contents of other websites. No separate library, login or audio engine.
Old standalone-extension login tokens are cleared on update; old unsent
listening progress is retained in its existing extension storage.

TESTING
Popup controls and layout, bridge message validation, player routing,
login-token migration, and tab-to-background handoff passed automated
checks. Chrome extension APIs were mocked in those checks; real Chrome
shared sign-in and background audio still require a check in your profile.

Guide: https://hasbreo.com/tempo/chrome
