(() => {
  const protocol='tempo.chrome.v1',channel=crypto.randomUUID(),origin=location.origin;
  let port,helloTimer,reconnect;
  function connect(){
    clearTimeout(reconnect);clearInterval(helloTimer);
    port=chrome.runtime.connect({name:'tempo-web'});
    port.onMessage.addListener(message=>{
      if(message.type==='command')window.postMessage({protocol,channel,type:'command',id:message.id,command:message.command,args:message.args||{}},origin);
    });
    port.onDisconnect.addListener(()=>{clearInterval(helloTimer);reconnect=setTimeout(connect,1500);});
    const hello=()=>window.postMessage({protocol,channel,type:'hello'},origin);
    hello();helloTimer=setInterval(hello,2000);
  }
  window.addEventListener('message',event=>{
    if(event.source!==window||event.origin!==origin)return;
    const m=event.data;if(m?.protocol!==protocol||m.channel!==channel||!['state','reply'].includes(m.type))return;
    try{port.postMessage(m);}catch{}
  });
  connect();
})();
