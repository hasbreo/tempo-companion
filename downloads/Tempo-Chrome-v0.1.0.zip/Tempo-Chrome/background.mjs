import {serverBase,mediaUrl,cleanBook,normalize,remote,same,decision,mergeRemote,snapshotBook,chapterWindow,safePosition} from './model.mjs';
let auth=null,settings={speed:1,volume:.85},accounts={},scope='',remember=true;
let live={id:null,position:0,paused:true,phase:'',problem:''},notice='',readyPromise,creating,syncing,commands=Promise.resolve(),saving=Promise.resolve(),renewing;
const ports=new Set(),covers=new Map();
const key=()=>auth?auth.base+'|'+auth.id:'';
const account=()=>accounts[scope]||(accounts[scope]={books:[],libraries:[],libraryId:'',progress:{},current:null,lastId:''});
function progress(id){const a=account();return a.progress[id]||(a.progress[id]={pos:0,pending:false,hold:false,base:null,observed:null,updated:0,duration:0,wait:''});}
async function ready(){
  if(!readyPromise)readyPromise=(async()=>{
    await chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
    const [saved,session]=await Promise.all([chrome.storage.local.get('tempo'),chrome.storage.session.get('auth')]);
    const state=saved.tempo||{};settings={...settings,...state.settings};accounts=state.accounts||{};
    auth=session.auth||state.auth||null;remember=state.remember!==false;scope=key();
    if(auth){const a=account();live.id=a.lastId||null;live.position=live.id?progress(live.id).pos:0;}
    await chrome.alarms.create('tempo-sync',{periodInMinutes:1});
  })();return readyPromise;
}
function persist(){
  const copy=structuredClone({auth:remember?auth:null,remember,settings,accounts});
  saving=saving.catch(()=>{}).then(()=>chrome.storage.local.set({tempo:copy}));return saving;
}
function snapshot(){
  const a=auth?account():null;
  return {connected:!!auth,account:auth?{base:auth.base,name:auth.name}:null,settings,books:(a?.books||[]).map(snapshotBook),libraries:a?.libraries||[],libraryId:a?.libraryId||'',progress:a?.progress||{},current:snapshotBook(a?.current),audio:live,notice,version:chrome.runtime.getManifest().version};
}
function broadcast(){const state=snapshot();for(const port of ports){try{port.postMessage({type:'state',state});}catch{ports.delete(port);}}}
function safeSender(sender){return sender.id===chrome.runtime.id&&sender.url?.startsWith(chrome.runtime.getURL('card.html'));}
async function isCard(sender,nonce){
  if(!safeSender(sender))return false;
  if(sender.url===chrome.runtime.getURL('card.html')+'?popup')return !sender.tab||sender.tab.url===sender.url;
  const record=(await chrome.storage.session.get('card:'+sender.tab.id))['card:'+sender.tab.id];
  return !!record&&record.nonce===nonce&&sender.url===chrome.runtime.getURL('card.html')+'#'+nonce;
}
async function api(path,method='GET',body,missing=false){
  const a=auth;if(!a)throw Error('Connect to Audiobookshelf first.');
  const send=()=>fetch(a.base+'/'+path,{method,headers:{Authorization:'Bearer '+a.token,...(body!==undefined?{'Content-Type':'application/json'}:{})},body:body===undefined?undefined:JSON.stringify(body),redirect:'error',cache:'no-store',signal:AbortSignal.timeout(15000)});
  let result=await send();if(auth!==a)throw Error('The connection changed.');
  if(result.status===401&&a.refresh){await renew(a);result=await send();}
  if(auth!==a)throw Error('The connection changed.');
  if(result.status===404&&missing)return null;
  if(!result.ok)throw Error(result.status===401?'Your ABS login expired. Reconnect in Settings. Saved progress is retained.':result.status===403?'ABS denied access. Check your account permissions.':`Audiobookshelf returned HTTP ${result.status}. Try again.`);
  return result;
}
async function json(path,method='GET',body,missing=false){const result=await api(path,method,body,missing);if(!result)return null;const text=await result.text();if(!text||text.trim()==='OK')return null;return JSON.parse(text);}
async function renew(a){
  if(renewing)return renewing;
  renewing=(async()=>{
    const result=await fetch(a.base+'/auth/refresh',{method:'POST',headers:{'x-refresh-token':a.refresh},redirect:'error',signal:AbortSignal.timeout(15000)});
    if(!result.ok||auth!==a)throw Error('Reconnect to ABS in Settings. Saved progress is retained.');
    const data=await result.json(),token=data.user?.accessToken||data.accessToken;
    if(!token)throw Error('ABS could not renew this login. Reconnect in Settings.');
    a.token=token;a.refresh=data.user?.refreshToken||data.refreshToken||a.refresh;
    await chrome.storage.session.set({auth:a});await persist();
  })().finally(()=>{renewing=null;});return renewing;
}
async function hasAudio(){return (await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[chrome.runtime.getURL('audio.html')]})).length>0;}
async function ensureAudio(){
  if(await hasAudio())return;
  if(!creating)creating=chrome.offscreen.createDocument({url:'audio.html',reasons:['AUDIO_PLAYBACK'],justification:'Keep the selected audiobook playing when the floating Tempo card is closed.'}).finally(()=>{creating=null;});
  await creating;
}
async function audio(command,extra={},create=false){
  if(create)await ensureAudio();else if(!await hasAudio())return null;
  const result=await chrome.runtime.sendMessage({target:'audio',command,...extra});
  if(result?.error)throw Error(result.error);
  if(result?.state)await acceptAudio(result.state);
  return result?.state||null;
}
async function acceptAudio(state){
  if(!auth||state.account!==scope)return;
  const was=live;live=state;
  if(state.id){const p=progress(state.id);if(!state.phase&&Math.abs(p.pos-state.position)>.1){p.pos=state.position;p.duration=account().current?.duration||state.duration;p.pending=true;p.updated=Date.now();await persist();}}
  broadcast();
  chrome.action.setBadgeText({text:state.paused?'':'▶'}).catch(()=>{});chrome.action.setBadgeBackgroundColor({color:'#087e5d'}).catch(()=>{});
  if(state.id&&!state.phase&&((state.paused&&!was.paused)||Date.now()-(acceptAudio.lastSync||0)>30000)){
    acceptAudio.lastSync=Date.now();syncOne(state.id).catch(()=>{});
  }
}
async function read(id){return remote(await json('api/me/progress/'+encodeURIComponent(id),'GET',undefined,true));}
async function syncOne(id,force=false,expected=null){
  if(syncing){await syncing;if(force)return syncOne(id,true,expected);return;}
  const a=account(),accountKey=scope,p=progress(id);
  if(!auth||(!p.pending&&!force))return;
  syncing=(async()=>{
    try{
      const fresh=await read(id);if(scope!==accountKey)return;
      if(expected&&!same(expected,fresh)){p.observed=fresh;p.hold=true;throw Error('ABS changed again. Review both positions before choosing.');}
      p.observed=fresh;
      if(p.pending&&Math.abs(p.pos-fresh.pos)<1){p.base=fresh;p.pending=false;p.hold=false;p.wait='';return;}
      if(!force&&decision(p,fresh)!=='push'){p.hold=true;p.wait=fresh.pos>p.pos+1?'ABS is ahead. Choose the position you want to keep.':'Your ABS position changed. Choose which position to keep.';if(live.id===id&&!live.paused)await audio('pause');return;}
      const sent={pos:p.pos,updated:p.updated,duration:p.duration||a.current?.duration};
      if(!sent.duration)throw Error('Book duration is unavailable. Progress stays saved here.');
      await json('api/me/progress/'+encodeURIComponent(id),'PATCH',{currentTime:sent.pos,duration:sent.duration,progress:Math.min(1,sent.pos/sent.duration),isFinished:sent.pos>=sent.duration});
      const confirmed=await read(id);if(scope!==accountKey)return;
      if(Math.abs(confirmed.pos-sent.pos)>1)throw Error('ABS has not confirmed this position yet. It stays saved here.');
      p.base=confirmed;p.observed=confirmed;p.pending=p.updated!==sent.updated||Math.abs(p.pos-sent.pos)>.1;p.hold=false;p.wait='';
    }catch(error){if(scope===accountKey)p.wait=error instanceof TypeError?'ABS is unavailable. Progress is saved here and will retry.':error.message;}
    finally{if(scope===accountKey){await persist();broadcast();}}
  })().finally(()=>{syncing=null;});return syncing;
}
async function syncQueue(){if(!auth)return;for(const [id,p]of Object.entries(account().progress))if(p.pending&&!p.hold)await syncOne(id);}
async function refreshLibrary(libraryId){
  if(!auth)return;
  notice='Refreshing your library…';broadcast();
  const a=account(),accountKey=scope;
  try{
    const result=await json('api/libraries');
    a.libraries=(result.libraries||[]).filter(l=>l.mediaType!=='podcast').map(l=>({id:l.id,name:l.name}));
    if(libraryId&&!a.libraries.some(l=>l.id===libraryId))throw Error('This library is unavailable.');
    a.libraryId=libraryId||a.libraries.find(l=>l.id===a.libraryId)?.id||a.libraries[0]?.id||'';
    const next=[];
    if(a.libraryId){
      for(let page=0;page<100;page++){
        const data=await json(`api/libraries/${encodeURIComponent(a.libraryId)}/items?limit=100&page=${page}&minified=0`);
        const items=data.results||[];next.push(...items.map(cleanBook));
        if(items.length<100||(Number.isFinite(data.total)&&next.length>=data.total))break;
        if(page===99)throw Error('This library is larger than the extension can load. Use Tempo Web for the full collection.');
      }
    }
    const me=await json('api/me');if(scope!==accountKey)return;
    for(const raw of (me.user||me).mediaProgress||[]){if(raw.libraryItemId)mergeRemote(progress(raw.libraryItemId),remote(raw));}
    a.books=next.sort((x,y)=>x.title.localeCompare(y.title));notice='';covers.clear();
    if(a.current&&progress(a.current.id).hold&&!live.paused)await audio('pause');
    if(!a.current){const continued=next.filter(b=>{const p=progress(b.id);return p.pos>0&&!p.base?.finished;}).sort((x,y)=>(progress(y.id).updated||0)-(progress(x.id).updated||0));
      const b=next.find(b=>b.id===a.lastId)||continued[0];if(b){a.current=b;a.lastId=b.id;live={id:b.id,position:progress(b.id).pos,paused:true,phase:'',problem:''};}
    }else if(live.paused&&!progress(a.current.id).pending)live.position=progress(a.current.id).pos;
    await persist();
  }catch(error){notice=error instanceof TypeError?'ABS is unavailable. Your saved library and progress are retained.':error.message;throw Error(notice);}
  finally{broadcast();}
}
async function start(id){
  const a=account();
  if(live.id){await audio('pause');await syncOne(live.id);}
  const book=normalize(await json('api/items/'+encodeURIComponent(id)+'?expanded=1'));
  if(!book.tracks.length)throw Error('This book has no playable audio tracks.');
  const p=progress(id),fresh=await read(id);mergeRemote(p,fresh);p.duration=book.duration;
  a.current=snapshotBook(book);a.lastId=id;live={id,account:scope,position:p.pos,paused:true,phase:'',problem:''};
  await persist();broadcast();
  if(p.hold)throw Error(p.wait);
  const plan={account:scope,id,title:book.title,author:book.author,duration:book.duration,position:p.pos,speed:settings.speed,volume:settings.volume,tracks:book.tracks.map(t=>({startOffset:t.startOffset||0,duration:t.duration,url:mediaUrl(t,auth)}))};
  await audio('load',{plan},true);notice='';broadcast();
}
async function seek(position){
  const a=account(),b=a.current;if(!b)throw Error('Choose a book first.');
  const p=progress(b.id);if(p.hold)throw Error('Choose a sync position before seeking.');
  const target=safePosition(position,b.duration),state=await audio('state');
  if(state?.id===b.id)await audio('seek',{position:target,playAfter:!state.paused});
  else{live={...live,id:b.id,position:target,paused:true};}
  p.pos=target;p.duration=b.duration;p.pending=true;p.updated=Date.now();await persist();broadcast();
  if(live.paused)await syncOne(b.id);
}
async function handleCommand(type,args={}){
  await ready();
  if(type==='getState'){await audio('state');return snapshot();}
  if(type==='refresh'){await refreshLibrary(args.libraryId);return snapshot();}
  if(type==='login'){
    const base=serverBase(args.base),pattern=new URL(base).origin+'/*';
    if(!await chrome.permissions.contains({origins:[pattern]}))throw Error('Allow access to your ABS server, then connect again.');
    let token=String(args.token||'').trim(),refresh='',name='',id='';
    if(args.mode!=='token'){
      const result=await fetch(base+'/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:args.username,password:args.password}),redirect:'error',signal:AbortSignal.timeout(15000)});
      if(!result.ok)throw Error('Login failed. Check your username and password.');
      const data=await result.json();token=data.user?.accessToken||data.user?.token||data.accessToken;refresh=data.user?.refreshToken||data.refreshToken||'';
    }
    if(!token)throw Error('ABS did not return a supported access token.');
    const verify=await fetch(base+'/api/me',{headers:{Authorization:'Bearer '+token},redirect:'error',signal:AbortSignal.timeout(15000)});
    if(!verify.ok)throw Error('ABS did not accept this login.');
    const result=await verify.json(),user=result.user||result;id=user.id;name=user.username||'ABS user';
    if(!id)throw Error('ABS did not return an account identity.');
    if(auth){await audio('pause');if(live.id)await syncOne(live.id);await audio('stop');}
    auth={base,token,refresh,id,name};remember=args.remember!==false;scope=key();notice='';live={id:account().lastId||null,position:account().lastId?progress(account().lastId).pos:0,paused:true,phase:'',problem:''};
    await chrome.storage.session.set({auth});await persist();await refreshLibrary();return snapshot();
  }
  if(type==='logout'){
    await audio('pause');if(live.id)await syncOne(live.id);await audio('stop');
    auth=null;scope='';notice='';live={id:null,position:0,paused:true,phase:'',problem:''};covers.clear();await chrome.storage.session.remove('auth');await persist();broadcast();return snapshot();
  }
  if(!auth)throw Error('Connect to Audiobookshelf first.');
  if(type==='play'){await start(String(args.id));return snapshot();}
  if(type==='toggle'){
    const state=await audio('state');
    if(state&&!state.paused){await audio('pause');if(live.id)await syncOne(live.id);}
    else if(account().current)await start(account().current.id);
    else throw Error('Choose a book from your library.');
    return snapshot();
  }
  if(type==='pause'){await audio('pause');if(live.id)await syncOne(live.id);return snapshot();}
  if(type==='seek'){await seek(args.position);return snapshot();}
  if(type==='skip'){await seek((live.position||0)+Number(args.delta));return snapshot();}
  if(type==='chapter'){
    const b=account().current,c=chapterWindow(b,live.position),chapters=b?.chapters||[];
    let i=c.index+Number(args.direction);if(args.direction<0&&live.position-c.start>3)i=c.index;
    await seek(chapters[Math.max(0,Math.min(chapters.length-1,i))]?.start||0);return snapshot();
  }
  if(type==='settings'){
    if(args.speed!==undefined){const n=Number(args.speed);if(!Number.isFinite(n)||n<.5||n>3)throw Error('Speed must be between 0.5× and 3×.');settings.speed=n;}
    if(args.volume!==undefined){const n=Number(args.volume);if(!Number.isFinite(n)||n<0||n>1)throw Error('Invalid volume.');settings.volume=n;}
    await audio('settings',settings);await persist();broadcast();return snapshot();
  }
  if(type==='pull'||type==='push'){
    const b=account().current;if(!b)throw Error('Choose a book.');const p=progress(b.id);
    await audio('pause');
    if(type==='pull'){
      const fresh=await read(b.id);p.pos=fresh.pos;p.base=fresh;p.observed=fresh;p.pending=false;p.hold=false;p.wait='';p.updated=fresh.stamp;
      await audio('stop');live={id:b.id,position:fresh.pos,paused:true,phase:'',problem:''};await persist();broadcast();
    }else{
      if(!p.observed)throw Error('Refresh the saved positions first.');
      await syncOne(b.id,true,p.observed);if(p.hold||p.pending)throw Error(p.wait||'ABS has not confirmed this position.');
    }
    return snapshot();
  }
  if(type==='cover'){
    const id=String(args.id),a=account();if(!a.books.some(b=>b.id===id)&&a.current?.id!==id)throw Error('Book unavailable.');
    const cacheKey=scope+'|'+id;if(covers.has(cacheKey))return {url:covers.get(cacheKey)};
    const response=await api('api/items/'+encodeURIComponent(id)+'/cover?width=320');
    const mime=(response.headers.get('content-type')||'').split(';')[0];if(!['image/jpeg','image/png','image/webp','image/avif','image/gif'].includes(mime))return {url:null};
    const data=new Uint8Array(await response.arrayBuffer());if(data.length>2000000)return {url:null};
    let binary='';for(let offset=0;offset<data.length;offset+=8192)binary+=String.fromCharCode(...data.subarray(offset,offset+8192));
    const url='data:'+mime+';base64,'+btoa(binary);if(covers.size>=100)covers.delete(covers.keys().next().value);covers.set(cacheKey,url);return {url};
  }
  throw Error('Unknown Tempo action.');
}
function queue(type,args){const job=commands.then(()=>handleCommand(type,args));commands=job.catch(()=>{});return job;}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.target!=='background')return;
  const handle=async()=>{
    await ready();
    if(message.type==='audioState'&&sender.url===chrome.runtime.getURL('audio.html')){await acceptAudio(message.state);return {ok:true};}
    if(message.type==='mediaCommand'&&sender.url===chrome.runtime.getURL('audio.html'))return {ok:true,state:await queue(message.command,message.args)};
    if(message.type==='registerCard'&&sender.tab&&sender.frameId===0&&/^https?:/.test(sender.url||'')){
      const nonce=crypto.randomUUID();await chrome.storage.session.set({['card:'+sender.tab.id]:{nonce}});return {nonce};
    }
    if(message.type==='cardClosed'&&sender.tab){
      const record=(await chrome.storage.session.get('card:'+sender.tab.id))['card:'+sender.tab.id];
      if(record?.nonce===message.nonce)await chrome.storage.session.remove('card:'+sender.tab.id);return {ok:true};
    }
    if(message.type==='cardFallback'&&sender.tab&&sender.frameId===0){
      const record=(await chrome.storage.session.get('card:'+sender.tab.id))['card:'+sender.tab.id];
      if(record?.nonce!==message.nonce)throw Error('This Tempo card is no longer open.');
      await chrome.tabs.sendMessage(sender.tab.id,{target:'overlay',type:'close',nonce:message.nonce});
      await chrome.windows.create({url:chrome.runtime.getURL('card.html')+'?popup',type:'popup',width:450,height:720});return {ok:true};
    }
    if(!await isCard(sender,message.nonce))throw Error('Open Tempo using its Chrome toolbar icon.');
    if(message.type==='hideCard'){
      if(sender.tab)await chrome.tabs.sendMessage(sender.tab.id,{target:'overlay',type:'close',nonce:message.nonce});return {ok:true};
    }
    // Artwork fetches must never block the command queue behind dozens of covers.
    return {ok:true,result:await (message.type==='cover'?handleCommand('cover',message.args):queue(message.type,message.args))};
  };
  handle().then(reply,error=>{notice=error instanceof TypeError?'ABS is unavailable. Your saved progress is retained.':error.message;broadcast();reply({error:notice});});return true;
});
chrome.runtime.onConnect.addListener(port=>{
  if(!port.name.startsWith('tempo:'))return;
  ready().then(async()=>{
    if(!await isCard(port.sender,port.name.slice(6))){port.disconnect();return;}
    ports.add(port);port.postMessage({type:'state',state:snapshot()});
    if(port.sender.tab&&port.sender.url.includes('#'))chrome.tabs.sendMessage(port.sender.tab.id,{target:'overlay',type:'ready',nonce:port.name.slice(6)}).catch(()=>{});
    port.onDisconnect.addListener(()=>ports.delete(port));
  }).catch(()=>{try{port.disconnect();}catch{}});
});
chrome.action.onClicked.addListener(async tab=>{
  try{await chrome.scripting.executeScript({target:{tabId:tab.id},files:['overlay.js']});}
  catch{
    // Chrome-owned and other protected pages cannot host injected cards.
    await chrome.windows.create({url:chrome.runtime.getURL('card.html')+'?popup',type:'popup',width:450,height:720});
  }
});
chrome.tabs.onRemoved.addListener(id=>{chrome.storage.session.remove('card:'+id);});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='tempo-sync')ready().then(syncQueue).catch(()=>{});});
