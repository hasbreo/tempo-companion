import {trackAt,safePosition} from './model.mjs';
const audio=document.getElementById('audio');
let plan=null,index=0,position=0,changing=false,phase='',problem='',generation=0,lastReport=0;
const status=()=>({account:plan?.account||null,id:plan?.id||null,position,paused:audio.paused,phase,problem,speed:audio.playbackRate,volume:audio.volume,duration:plan?.duration||0});
function report(force=false){if(!force&&Date.now()-lastReport<1800)return;lastReport=Date.now();chrome.runtime.sendMessage({target:'background',type:'audioState',state:status()}).catch(()=>{});}
function setPhase(value){phase=value;report(true);}
function metadata(){return new Promise((resolve,reject)=>{let timer;
  const cleanup=()=>{clearTimeout(timer);audio.removeEventListener('loadedmetadata',ready);audio.removeEventListener('error',fail);};
  const ready=()=>{cleanup();resolve();};const fail=()=>{cleanup();reject(Error('Audio could not be loaded. Check the connection or audio format.'));};
  audio.addEventListener('loadedmetadata',ready,{once:true});audio.addEventListener('error',fail,{once:true});
  timer=setTimeout(()=>{cleanup();reject(Error('The audio server took too long to respond. Try Play again.'));},30000);audio.load();
  if(audio.readyState>=1)ready();
});}
async function seek(value,playAfter=!audio.paused){
  if(!plan)throw Error('Choose a book first.');
  const gen=++generation,target=safePosition(value,plan.duration),next=trackAt(plan.tracks,target);
  changing=true;position=target;problem='';setPhase('Loading audio…');
  try{
    audio.pause();
    if(next!==index||!audio.getAttribute('src')){index=next;audio.src=plan.tracks[index].url;await metadata();}
    if(gen!==generation)return status();
    const offset=Math.max(0,target-(plan.tracks[index].startOffset||0));
    if(Math.abs(audio.currentTime-offset)>.05){
      await new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{cleanup();reject(Error('Audio seeking timed out. Try again.'));},15000);
        const cleanup=()=>{clearTimeout(timer);audio.removeEventListener('seeked',done);audio.removeEventListener('error',fail);};
        const done=()=>{cleanup();resolve();};const fail=()=>{cleanup();reject(Error('Could not seek in this audio file.'));};
        audio.addEventListener('seeked',done,{once:true});audio.addEventListener('error',fail,{once:true});audio.currentTime=offset;
        if(!audio.seeking)done();
      });
    }
    if(gen!==generation)return status();
    changing=false;audio.playbackRate=plan.speed;audio.volume=plan.volume;
    if(playAfter){setPhase('Starting playback…');await audio.play();}
    phase='';report(true);return status();
  }catch(error){if(gen===generation){changing=false;phase='';problem=error.message;audio.pause();report(true);}throw error;}
}
function mediaSession(){
  if(!('mediaSession'in navigator)||!plan)return;
  navigator.mediaSession.metadata=new MediaMetadata({title:plan.title,artist:plan.author,album:'Tempo'});
  for(const [name,type,args]of [['play','toggle',{}],['pause','pause',{}],['seekbackward','skip',{delta:-30}],['seekforward','skip',{delta:30}],['previoustrack','chapter',{direction:-1}],['nexttrack','chapter',{direction:1}]]){
    try{navigator.mediaSession.setActionHandler(name,()=>{chrome.runtime.sendMessage({target:'background',type:'mediaCommand',command:type,args}).catch(()=>{});});}catch{}
  }
}
async function command(message){
  if(message.command==='state')return status();
  if(message.command==='load'){
    generation++;changing=true;audio.pause();audio.removeAttribute('src');audio.load();
    plan=message.plan;index=0;position=plan.position;mediaSession();
    return seek(plan.position,true);
  }
  if(message.command==='pause'){generation++;changing=false;audio.pause();phase='';report(true);return status();}
  if(message.command==='play'){if(!plan)throw Error('Choose a book.');problem='';await audio.play();phase='';report(true);return status();}
  if(message.command==='seek')return seek(message.position,message.playAfter);
  if(message.command==='settings'){
    if(plan){plan.speed=message.speed;plan.volume=message.volume;}
    audio.playbackRate=message.speed;audio.volume=message.volume;report(true);return status();
  }
  if(message.command==='stop'){generation++;changing=true;audio.pause();audio.removeAttribute('src');audio.load();plan=null;position=0;phase='';problem='';changing=false;report(true);return status();}
  throw Error('Unknown playback command.');
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.target!=='audio'||sender.id!==chrome.runtime.id)return;
  command(message).then(state=>reply({ok:true,state}),error=>reply({error:error.message}));return true;
});
audio.addEventListener('timeupdate',()=>{
  if(!plan||changing||audio.seeking)return;
  position=Math.min(plan.duration,(plan.tracks[index]?.startOffset||0)+audio.currentTime);report();
  if('mediaSession'in navigator&&Number.isFinite(plan.duration)&&plan.duration>0)try{navigator.mediaSession.setPositionState({duration:plan.duration,position,playbackRate:audio.playbackRate});}catch{}
});
audio.addEventListener('playing',()=>{phase='';problem='';report(true);});
audio.addEventListener('pause',()=>{if(!changing)report(true);});
audio.addEventListener('waiting',()=>{if(!audio.paused&&!changing)setPhase('Buffering audio…');});
audio.addEventListener('error',()=>{if(plan&&!changing){problem='Audio unavailable. Try Play again or check your ABS connection.';phase='';report(true);}});
audio.addEventListener('ended',async()=>{
  if(!plan||changing)return;
  try{if(index<plan.tracks.length-1)await seek(plan.tracks[index+1].startOffset||0,true);else{position=plan.duration;phase='';report(true);}}catch{}
});
setInterval(()=>{if(plan&&!changing)report(true);},2000);
