(() => {
  'use strict';
  if(globalThis.__tempoFloat){globalThis.__tempoFloat.toggle();return;}
  let host=null,nonce='',lastFocus=null,readyTimer;
  function close(){clearTimeout(readyTimer);if(!host)return;host.remove();host=null;document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);if(lastFocus?.isConnected)lastFocus.focus?.({preventScroll:true});chrome.runtime.sendMessage({target:'background',type:'cardClosed',nonce}).catch(()=>{});}
  function outside(e){if(host&&!e.composedPath().includes(host))close();}
  function key(e){if(e.key==='Escape')close();}
  async function open(){
    const result=await chrome.runtime.sendMessage({target:'background',type:'registerCard'});
    if(!result?.nonce)return;
    nonce=result.nonce;lastFocus=document.activeElement;
    host=document.createElement('div');
    host.setAttribute('data-tempo-player','');
    const styles={all:'initial',position:'fixed',top:'72px',right:'20px',width:'min(420px, calc(100vw - 32px))',height:'min(650px, calc(100dvh - 96px))','min-height':'220px','z-index':'2147483647',display:'block','color-scheme':'dark'};
    for(const [key,value]of Object.entries(styles))host.style.setProperty(key,value,'important');
    const shadow=host.attachShadow({mode:'closed'});
    const style=document.createElement('style');
    style.textContent=':host{contain:layout style} .glass{width:100%;height:100%;border-radius:22px;overflow:hidden;background:rgba(7,29,22,.81);border:1px solid rgba(171,255,218,.24);box-shadow:0 24px 80px #0007,inset 0 1px 0 #ffffff16;backdrop-filter:blur(26px) saturate(1.35);-webkit-backdrop-filter:blur(26px) saturate(1.35)}iframe{display:block;width:100%;height:100%;border:0;background:transparent;color-scheme:dark}';
    const glass=document.createElement('div');glass.className='glass';
    const frame=document.createElement('iframe');frame.title='Tempo floating audiobook player';frame.src=chrome.runtime.getURL('card.html')+'#'+nonce;frame.allow='autoplay';frame.setAttribute('referrerpolicy','no-referrer');
    // CSSOM assignments also work on sites that disallow inline <style> tags.
    Object.assign(glass.style,{width:'100%',height:'100%',borderRadius:'22px',overflow:'hidden',background:'rgba(7,29,22,.81)',border:'1px solid rgba(171,255,218,.24)',boxShadow:'0 24px 80px #0007,inset 0 1px 0 #ffffff16',backdropFilter:'blur(26px) saturate(1.35)',webkitBackdropFilter:'blur(26px) saturate(1.35)'});
    Object.assign(frame.style,{display:'block',width:'100%',height:'100%',border:'0',background:'transparent',colorScheme:'dark'});
    glass.append(frame);shadow.append(style,glass);document.documentElement.append(host);
    readyTimer=setTimeout(()=>{if(host)chrome.runtime.sendMessage({target:'background',type:'cardFallback',nonce}).catch(()=>{});},4500);
    // Clicks inside the cross-origin frame stay inside it. Outside clicks keep working normally.
    setTimeout(()=>{if(host)document.addEventListener('pointerdown',outside,true);},0);
    document.addEventListener('keydown',key,true);
  }
  globalThis.__tempoFloat={toggle:()=>host?close():open()};
  chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    if(message.target!=='overlay')return;
    if(message.type==='ready'&&message.nonce===nonce)clearTimeout(readyTimer);
    if(message.type==='close'&&message.nonce===nonce)close();
    reply({ok:true});
  });
  open();
})();
