import {normalize,remote,same,decision,trackAt} from './core.mjs';
export {normalize,remote,same,decision,trackAt};
export const DEFAULT_SERVER='https://abs.hasbreo.com';
export function serverBase(value){
  const u=new URL(String(value).trim());
  if((u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)))||u.username||u.password||u.search||u.hash)throw Error('Use an HTTPS Audiobookshelf address, without a username or token in the URL.');
  return u.href.replace(/\/+$/,'');
}
export function mediaUrl(track,auth){
  const url=new URL(track.contentUrl,auth.base+'/');
  if(url.origin!==new URL(auth.base).origin||url.username||url.password||url.hash||url.search)throw Error('ABS returned an unsupported audio address.');
  url.searchParams.set('token',auth.token);
  return url.href;
}
export function cleanBook(item){
  const b=normalize(item);
  return {id:b.id,title:b.title,author:b.author,authors:b.authors,series:b.series,duration:b.duration,addedAt:b.addedAt,updatedAt:b.updatedAt,chapters:b.chapters};
}
export function chapterWindow(book,pos){
  const chapters=book?.chapters||[];
  const i=chapters.findLastIndex(c=>c.start<=pos);
  const c=chapters[i];
  return {index:i,start:c?.start||0,end:c?.end||chapters[i+1]?.start||book?.duration||1,title:c?.title||'Audiobook'};
}
export function safePosition(value,duration){
  const n=Number(value);if(!Number.isFinite(n))throw Error('Invalid playback position.');
  return Math.max(0,Math.min(Number(duration)||0,n));
}
export function mergeRemote(local,fresh){
  if(local.pending&&Math.abs(local.pos-fresh.pos)<1){local.base=fresh;local.pending=false;local.hold=false;local.wait='';}
  else if(local.pending&&(!local.base||!same(local.base,fresh))){local.hold=true;local.wait='Your ABS position changed on another device. Choose which position to keep.';}
  else if(!local.pending){local.pos=fresh.pos;local.base=fresh;local.hold=false;local.wait='';local.updated=fresh.stamp;}
  local.observed=fresh;
  return local;
}
export function snapshotBook(book){
  if(!book)return null;
  return {id:book.id,title:book.title,author:book.author,authors:book.authors||[],series:book.series||[],duration:book.duration||0,addedAt:book.addedAt||0,chapters:book.chapters||[]};
}
