import {chapterWindow,serverBase,DEFAULT_SERVER} from './model.mjs';
const $=s=>document.querySelector(s),main=$('#main'),nonce=location.hash.slice(1);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>{n=Math.floor(Math.max(0,n||0));return n>=3600?Math.floor(n/3600)+':'+String(Math.floor(n%3600/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0'):Math.floor(n/60)+':'+String(n%60).padStart(2,'0');};
const paths={home:'M3 10 12 3l9 7M5 9v12h5v-7h4v7h5V9',library:'M4 4h4v16H4zM8 4h4v16H8M15 4l4-1 4 16-4 1z',player:'M7 4v16l14-8z',pause:'M7 5h3v14H7zM14 5h3v14h-3z',close:'m6 6 12 12M6 18 18 6',refresh:'M20 11a8 8 0 1 0-2 6M20 4v7h-7',settings:'m9 3 6 0 1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1zM15 12a3 3 0 1 0-6 0 3 3 0 0 0 6 0',skip:'M7 8a8 8 0 1 1-2 8M3 8l5-4v8z',prev:'M18 4v16L7 12zM4 4h2v16H4z',next:'M6 4v16l11-8zM18 4h2v16h-2z',volume:'M3 9h4l5-4v14l-5-4H3zM16 8a6 6 0 0 1 0 8M19 5a10 10 0 0 1 0 14',back:'m14 6-6 6 6 6',search:'M21 21l-5-5M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16',external:'M14 3h7v7M21 3 11 13M11 3H3v18h18v-8'};
function icon(name){const fill=['player','pause','prev','next'].includes(name);return `<svg viewBox="0 0 24 24" aria-hidden="true" fill="${fill?'currentColor':'none'}" stroke="${fill?'none':'currentColor'}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[name]||paths.player}"/></svg>`;}
let state=null,view='home',mode='books',query='',group='',busy=false,chapters=false,port,reconnectTimer,initialRefresh=false,loginMode='password';
const art=new Map(),pendingArt=new Set();let activeArt=0;
if(location.search==='?popup')document.body.classList.add('standalone');
$('#refresh').innerHTML=icon('refresh');$('#settings').innerHTML=icon('settings');$('#close').innerHTML=icon('close');
for(const button of document.querySelectorAll('[data-view]'))button.innerHTML=icon(button.dataset.view==='player'?'player':button.dataset.view)+`<span>${{home:'Home',player:'Now playing',library:'Library'}[button.dataset.view]}</span>`;
function error(message){$('#error').hidden=!message;$('#error').textContent=message||'';}
async function send(type,args){const response=await chrome.runtime.sendMessage({target:'background',type,args,nonce});if(response?.error)throw Error(response.error);if(!response?.ok)throw Error('Tempo could not respond. Try reopening the card.');return response.result;}
async function action(type,args){if(busy)return;busy=true;error('');renderBusy();try{const result=await send(type,args);if(result?.books){state=result;render();}return result;}catch(e){error(e.message);}finally{busy=false;renderBusy();}}
function renderBusy(){main.setAttribute('aria-busy',String(busy));$('#refresh').classList.toggle('spinner',busy);main.querySelectorAll('[data-action],form button[type="submit"]').forEach(b=>b.disabled=busy);}
function p(id){return state?.progress?.[id]||{pos:0,base:null};}
function cover(book,classes=''){return `<div class="cover ${classes}" data-cover="${esc(book.id)}">${esc(book.title.split(/\s+/).slice(0,2).map(x=>x[0]).join(''))}${art.get(book.id)?`<img src="${art.get(book.id)}" alt="">`:''}</div>`;}
function seriesLabel(book){return (book.series||[]).map(s=>s.name+(s.sequence!==undefined&&s.sequence!==null&&s.sequence!==''?' · '+s.sequence:'')).join(' · ');}
function row(book){const progress=p(book.id);return `<button class="book-row" data-action="play" data-id="${esc(book.id)}" aria-label="Play ${esc(book.title)}">${cover(book)}<span class="info"><strong>${esc(book.title)}</strong><small>${esc(book.author)}</small>${seriesLabel(book)?`<small>${esc(seriesLabel(book))}</small>`:''}<small>${progress.pos?fmt(progress.pos)+' / ':''}${fmt(book.duration)}${progress.base?.finished?' · Finished':''}</small></span>${icon('player')}</button>`;}
function conflict(){const book=state.current,progress=book&&p(book.id);if(!progress?.hold)return '';return `<section class="conflict" role="status"><strong>Choose your listening position</strong><p>${esc(progress.wait||'ABS changed on another device.')}</p><div class="positions"><span>Extension: ${fmt(progress.pos)}</span><span>ABS: ${fmt(progress.observed?.pos||0)}</span></div><div class="actions"><button class="primary" data-action="pull">Use ABS position</button><button class="button" data-action="push">Use extension position</button></div></section>`;}
function home(){
  const continued=state.books.filter(b=>p(b.id).pos>0&&!p(b.id).base?.finished).sort((a,b)=>(p(b.id).updated||0)-(p(a.id).updated||0));
  const book=state.current||continued[0];
  return `<p class="eyebrow">YOUR LISTENING ROOM</p><h1>A little time<br>for a good story.</h1>${book?`<section class="hero">${cover(book)}<div><h2>${esc(book.title)}</h2><p>${esc(book.author)}</p>${seriesLabel(book)?`<p>${esc(seriesLabel(book))}</p>`:''}<button class="primary" data-action="${state.current?.id===book.id&&!state.audio.paused?'toggle':'play'}" data-id="${esc(book.id)}">${icon(state.current?.id===book.id&&!state.audio.paused?'pause':'player')}${state.current?.id===book.id&&!state.audio.paused?'Pause':'Continue listening'}</button></div></section>`:''}${conflict()}<div class="section-title"><h2>Continue listening</h2><span>${continued.length} books</span></div>${continued.slice(0,6).map(row).join('')||'<p class="help">Choose a book from your library to begin.</p>'}<div class="section-title"><h2>Recently added</h2></div>${[...state.books].sort((a,b)=>b.addedAt-a.addedAt).slice(0,8).map(row).join('')}`;
}
function player(){
  const book=state.current;if(!book)return `<img src="logo.svg" class="logo-empty" alt=""><h1>Your next chapter.</h1><p class="empty">Choose a book from Home or Library to start listening.</p><button class="primary full" data-local="library">Browse library</button>`;
  const position=state.audio.position??p(book.id).pos??0,ch=chapterWindow(book,position),progress=p(book.id),loading=!!state.audio.phase;
  return `<section class="player">${cover(book,'player-cover')}<div class="player-heading"><h1>${esc(book.title)}</h1><p>${esc(book.author)}</p>${seriesLabel(book)?`<div class="series-label">${esc(seriesLabel(book))}</div>`:''}</div>${conflict()}<div class="chapter-heading"><span id="chapter-name">${esc(ch.title)}</span><button class="quiet-link" data-local="chapters">${chapters?'Hide chapters':'Chapters'}</button></div><div class="timeline"><label class="sr" for="chapter-seek">Position in chapter</label><input id="chapter-seek" type="range" min="${ch.start}" max="${ch.end}" step="1" value="${position}"><div class="times"><span id="chapter-elapsed">${fmt(position-ch.start)}</span><span id="chapter-length">${fmt(ch.end-ch.start)}</span></div><div class="times total" id="book-time">${fmt(position)} / ${fmt(book.duration)} in book</div></div><div class="transport"><button data-action="chapter" data-direction="-1" aria-label="Previous chapter">${icon('prev')}</button><button class="skip" data-action="skip" data-delta="-30" aria-label="Skip back 30 seconds">${icon('skip')}<span>30</span></button><button class="play ${loading?'loading':''}" data-action="toggle" aria-label="${loading?'Loading audio':state.audio.paused?'Play':'Pause'}">${icon(loading?'refresh':state.audio.paused?'player':'pause')}</button><button class="skip next" data-action="skip" data-delta="30" aria-label="Skip forward 30 seconds">${icon('skip')}<span>30</span></button><button data-action="chapter" data-direction="1" aria-label="Next chapter">${icon('next')}</button></div><div class="player-extras"><label><span class="sr">Playback speed</span><select id="speed">${[.5,.75,1,1.1,1.25,1.5,1.75,2,2.5,3].map(n=>`<option value="${n}" ${state.settings.speed===n?'selected':''}>${n}× speed</option>`).join('')}</select></label><label class="volume">${icon('volume')}<span class="sr">Volume</span><input id="volume" type="range" min="0" max="1" step=".05" value="${state.settings.volume}"></label></div><p class="status ${progress.pending||progress.hold?'warn':''}" id="player-status">${esc(state.audio.phase||state.audio.problem||progress.wait||(progress.hold?'Sync needs your choice':progress.pending?'Progress saved here · waiting for ABS':'Position synced with ABS'))}</p>${chapters?`<div class="chapters">${book.chapters.map(c=>`<button class="chapter-row" data-action="seek" data-position="${c.start}"><span>${esc(c.title||'Chapter')}</span><span>${fmt(c.start)}</span></button>`).join('')||'<p class="help">No chapters were provided by ABS.</p>'}</div>`:''}</section>`;
}
function library(){
  let books=state.books.filter(b=>`${b.title} ${b.author} ${seriesLabel(b)}`.toLowerCase().includes(query.toLowerCase()));
  let content;
  if(mode!=='books'&&!group){
    const groups=new Map();for(const b of books)for(const name of mode==='series'?(b.series||[]).map(s=>s.name):b.authors?.length?b.authors:[b.author]){if(!name)continue;groups.set(name,(groups.get(name)||0)+1);}
    content=[...groups].sort((a,b)=>a[0].localeCompare(b[0])).map(([name,count])=>`<button class="group" data-group="${esc(name)}"><span>${esc(name)}</span><small>${count} books</small></button>`).join('')||'<p class="empty">No matching groups.</p>';
  }else{
    if(group)books=books.filter(b=>mode==='series'?b.series.some(s=>s.name===group):(b.authors?.length?b.authors:[b.author]).includes(group));
    if(mode==='series'&&group)books.sort((a,b)=>Number(a.series.find(s=>s.name===group)?.sequence??Infinity)-Number(b.series.find(s=>s.name===group)?.sequence??Infinity));
    content=books.slice(0,80).map(row).join('')||'<p class="empty">No books match. Try a different search or library.</p>';
    if(books.length>80)content+='<p class="help">Showing 80 books. Search to narrow the list.</p>';
  }
  return `${group?`<button class="quiet-link back" data-local="ungroup">${icon('back')}All ${mode==='series'?'series':'authors'}</button>`:''}<div class="view-top"><h1>${esc(group||'Your library')}</h1>${!group&&state.libraries.length>1?`<select id="library-select" aria-label="Library">${state.libraries.map(l=>`<option value="${esc(l.id)}" ${l.id===state.libraryId?'selected':''}>${esc(l.name)}</option>`).join('')}</select>`:''}</div><div class="search"><label class="sr" for="search">Search books, authors and series</label><input id="search" type="search" placeholder="Search books, authors & series" value="${esc(query)}"><button class="icon" data-local="clear" aria-label="Clear search">${icon('close')}</button></div>${!group?`<div class="subnav" aria-label="Library view">${[['books','Books'],['series','Series'],['authors','Authors']].map(([id,label])=>`<button data-mode="${id}" class="${mode===id?'active':''}" aria-pressed="${mode===id}">${label}</button>`).join('')}</div>`:''}${content}`;
}
function settingsPage(){return `<p class="eyebrow">YOUR TEMPO</p><h1>Connection & settings</h1><div class="settings-row"><h2>Audiobookshelf</h2><p>${esc(state.account.name)}<br>${esc(state.account.base)}</p><button class="button section danger" data-action="logout">Disconnect</button></div><div class="settings-row"><h2>Playback & sync</h2><p>Progress saves locally while listening, checks ABS before playing, and pushes on pause. Queued changes retry while Chrome is running. Conflicts wait for your choice.</p><p>Closing this card keeps audio playing. Closing Chrome stops playback.</p><button class="button section" data-action="pull">Pull ABS position</button></div><div class="settings-row"><h2>More room for your library</h2><p><a href="https://tempo.hasbreo.com" target="_blank" rel="noopener noreferrer">Open Tempo Web ↗</a></p><p>This first extension version streams from ABS. It doesn’t download books for offline listening.</p></div><p class="version">Tempo for Chrome · ${esc(state.version)}<br>Login tokens stay in this Chrome profile. Your password isn’t stored.</p>`;}
function login(){return `<p class="eyebrow">A LITTLE TEMPO, EVERYWHERE</p><h1>Your library.<br>Within reach.</h1><form id="connect"><p>Connect directly to Audiobookshelf.</p><label class="field">Server address<input type="url" name="base" value="${DEFAULT_SERVER}" required autocomplete="url"></label><label class="field">Sign in with<select name="mode"><option value="password">Username & password</option><option value="token">API / access token</option></select></label><div id="password-fields"><label class="field">Username<input name="username" autocomplete="username"></label><label class="field">Password<input name="password" type="password" autocomplete="current-password"></label></div><div id="token-fields" hidden><label class="field">Access token<input name="token" type="password" autocomplete="off"></label></div><label class="check"><input type="checkbox" name="remember" checked>Keep me signed in on this Chrome profile</label><button class="primary full" type="submit">Connect your library</button><p class="help">Your login goes directly to your ABS server. Your password isn’t saved. Another server may prompt you to allow its address.</p></form>`;}
function mini(){const b=state.current;if(!b||view==='player'||view==='settings')return '';return `<div class="now-strip"><button data-local="player" aria-label="Open now playing">${cover(b)}</button><button data-local="player" class="info">${esc(b.title)}</button><button class="icon" data-action="toggle" aria-label="${state.audio.paused?'Play':'Pause'}">${icon(state.audio.paused?'player':'pause')}</button></div>`;}
let lastSignature='';
function signature(s){return JSON.stringify([s.connected,s.account,s.books,s.current,s.audio.paused,s.audio.phase,s.audio.problem,s.notice,s.settings,Object.entries(s.progress).filter(([id,p])=>p.hold||p.wait).map(([id,p])=>[id,p.hold,p.wait,p.observed]),view,mode,query,group,chapters]);}
function render(force=false){
  if(!state)return;
  const sig=signature(state);
  if(!force&&sig===lastSignature){updateTimes();return;}
  lastSignature=sig;
  const scroll=main.scrollTop,focused=document.activeElement?.id,selection=document.activeElement?.selectionStart;
  $('#tabs').hidden=!state.connected;$('#refresh').disabled=!state.connected;$('#settings').disabled=!state.connected;
  main.innerHTML=!state.connected?login():(view==='home'?home():view==='player'?player():view==='library'?library():settingsPage())+(state.notice?`<p class="notice">${esc(state.notice)}</p>`:'')+mini();
  for(const button of document.querySelectorAll('[data-view]'))button.classList.toggle('active',button.dataset.view===view);
  if(focused==='search'&&$('#search')){$('#search').focus();if(typeof selection==='number')$('#search').setSelectionRange(selection,selection);}
  main.scrollTop=scroll;renderBusy();hydrateArt();
}
function updateTimes(){
  const b=state.current;if(!b||view!=='player')return;
  const pos=state.audio.position??p(b.id).pos??0,ch=chapterWindow(b,pos),range=$('#chapter-seek');
  if(range&&document.activeElement!==range){range.min=ch.start;range.max=ch.end;range.value=pos;}
  if($('#chapter-name'))$('#chapter-name').textContent=ch.title;
  if($('#chapter-elapsed'))$('#chapter-elapsed').textContent=fmt(pos-ch.start);
  if($('#chapter-length'))$('#chapter-length').textContent=fmt(ch.end-ch.start);
  if($('#book-time'))$('#book-time').textContent=fmt(pos)+' / '+fmt(b.duration)+' in book';
  if($('#player-status')){$('#player-status').textContent=state.audio.phase||state.audio.problem||p(b.id).wait||(p(b.id).pending?'Progress saved here · waiting for ABS':'Position synced with ABS');$('#player-status').classList.toggle('warn',p(b.id).pending||p(b.id).hold);}
}
function hydrateArt(){
  for(const el of main.querySelectorAll('[data-cover]')){
    if(activeArt>=4)break;
    const id=el.dataset.cover;if(art.has(id)||pendingArt.has(id))continue;pendingArt.add(id);
    activeArt++;
    send('cover',{id}).then(result=>{art.set(id,result?.url||null);if(result?.url){for(const slot of main.querySelectorAll('[data-cover]'))if(slot.dataset.cover===id&&!slot.querySelector('img')){const img=document.createElement('img');img.src=result.url;img.alt='';slot.append(img);}}}).catch(()=>{art.set(id,null);}).finally(()=>{pendingArt.delete(id);activeArt--;hydrateArt();});
  }
}
function connectPort(){
  clearTimeout(reconnectTimer);port=chrome.runtime.connect({name:'tempo:'+nonce});
  port.onMessage.addListener(message=>{
    if(message.type!=='state')return;
    const changed=state?.account?.base!==message.state.account?.base||state?.account?.name!==message.state.account?.name;
    state=message.state;if(changed){art.clear();pendingArt.clear();initialRefresh=false;}
    render();main.setAttribute('aria-busy',String(busy));
    if(state.connected&&!initialRefresh){initialRefresh=true;send('refresh').catch(e=>error(e.message));}
  });
  port.onDisconnect.addListener(()=>{reconnectTimer=setTimeout(connectPort,1500);});
}
$('#close').onclick=()=>{if(location.search==='?popup')window.close();else send('hideCard').catch(()=>{});};
$('#refresh').onclick=()=>{art.clear();action('refresh');};
$('#settings').onclick=()=>{view=view==='settings'?'home':'settings';main.scrollTop=0;render(true);};
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#close').click();});
document.addEventListener('click',async e=>{
  const tab=e.target.closest('[data-view]');if(tab){view=tab.dataset.view;group='';query='';chapters=false;main.scrollTop=0;render(true);return;}
  const local=e.target.closest('[data-local]');if(local){const type=local.dataset.local;if(type==='chapters')chapters=!chapters;else if(type==='clear')query='';else if(type==='ungroup')group='';else view=type;render(true);return;}
  const m=e.target.closest('[data-mode]');if(m){mode=m.dataset.mode;group='';render(true);return;}
  const g=e.target.closest('[data-group]');if(g){group=g.dataset.group;render(true);return;}
  const button=e.target.closest('[data-action]');if(!button||button.disabled)return;
  const type=button.dataset.action,args={id:button.dataset.id,direction:Number(button.dataset.direction),delta:Number(button.dataset.delta),position:Number(button.dataset.position)};
  if(type==='play'){view='player';main.scrollTop=0;render(true);}
  await action(type,args);
});
main.addEventListener('input',e=>{if(e.target.id==='search'){query=e.target.value;render(true);}});
main.addEventListener('change',e=>{
  const el=e.target;
  if(el.name==='mode'){$('#password-fields').hidden=el.value==='token';$('#token-fields').hidden=el.value!=='token';loginMode=el.value;}
  if(el.id==='chapter-seek')action('seek',{position:Number(el.value)});
  if(el.id==='speed')action('settings',{speed:Number(el.value)});
  if(el.id==='volume')action('settings',{volume:Number(el.value)});
  if(el.id==='library-select'){art.clear();query='';group='';action('refresh',{libraryId:el.value});}
});
main.addEventListener('submit',async e=>{
  if(e.target.id!=='connect')return;e.preventDefault();if(busy)return;
  const form=new FormData(e.target),args={base:form.get('base'),mode:form.get('mode'),username:form.get('username'),password:form.get('password'),token:form.get('token'),remember:form.get('remember')==='on'};
  try{
    const base=serverBase(args.base),origin=new URL(base).origin+'/*';
    // Requested directly from the submit gesture, before any network operation.
    const allowed=await chrome.permissions.request({origins:[origin]});
    if(!allowed)throw Error('Server access wasn’t granted. Allow it to connect.');
    const result=await action('login',args);if(result?.connected){view='home';art.clear();render(true);}
  }catch(errorObject){error(errorObject.message);}
  finally{args.password='';args.token='';}
});
connectPort();
send('getState').then(result=>{state=result;render();main.setAttribute('aria-busy','false');}).catch(e=>{main.innerHTML='<p class="empty">Open Tempo using its Chrome toolbar icon. If the card has expired, close it and click the icon again.</p>';main.setAttribute('aria-busy','false');error(e.message);});
