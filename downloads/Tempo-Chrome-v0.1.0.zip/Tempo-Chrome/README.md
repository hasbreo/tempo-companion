# Tempo for Chrome — floating player

Version 0.1.0. A standalone Audiobookshelf player in a floating Tempo card.

## Install on your Windows PC

1. Right-click **Tempo-Chrome-v0.1.0.zip** and choose **Extract All**.
2. Move the extracted **Tempo-Chrome** folder somewhere permanent, such as Documents.
3. Type **chrome://extensions** in Chrome's address bar.
4. Turn on **Developer mode** at the top right.
5. Click **Load unpacked** and select the **Tempo-Chrome** folder containing **manifest.json**.
6. In Chrome's puzzle-piece Extensions menu, pin **Tempo — Floating Audiobook Player**.
7. Open a normal website and click the Tempo icon. The floating card opens at the top right.
8. Sign in with your Audiobookshelf details. The server address starts as **https://abs.hasbreo.com**. You can use another HTTPS ABS server; allow access to that server when Chrome asks.

Chrome 116 or newer is required. No build, terminal, extra app, or Tempo Web tab is needed to use the extension. Desktop Chrome is required.

## Using Tempo

- Home shows continue listening and recently added books.
- Library includes books, series, authors, search, and library selection when your ABS account has more than one library.
- Clicking a book starts it using its ABS position. Official chapter titles and series positions come from ABS.
- Now Playing includes play/pause, 30-second skips, previous/next chapter, a chapter scrubber, speed, volume, and a chapter list.
- Click the toolbar icon again, click outside, press Escape, or use the card's close button to hide it. Audio keeps playing while Chrome remains open.
- Reopen Tempo on another webpage or tab to control the same player.
- Chrome-owned pages, other protected pages, and websites that block embedded cards cannot host the floating card. On those pages Tempo opens in a small separate window instead. Frosted glass over a webpage applies to the floating card.
- The card is anchored at the top right; this version does not provide dragging or resizing.

## Progress and conflicts

The extension checks ABS before playing. Progress saves locally while listening, uploads periodically, and pushes on pause. Changes queued while disconnected retry while Chrome is running. Closing Chrome stops audio; the most recent local checkpoint remains saved.

If your phone, watch, or another player changes the ABS position, Tempo holds the conflicting upload. Choose **Use ABS position** or **Use extension position**. It rechecks ABS before an explicit upload and verifies the position after saving. Settings also has a manual **Pull ABS position** button.

This version streams audio. It does not download books for offline listening, handle podcasts, request new books, edit metadata, or record ABS listening-session statistics. It shares your book positions through ABS; it does not import cookies, credentials, appearance settings, or downloads from Tempo Phone, Watch, or Web.

## Privacy and access

Your login is sent directly to your selected ABS server. The extension stores access/refresh tokens in your Chrome profile when **Keep me signed in** is checked; otherwise the login is held for the browser session. It never stores your password. Settings, cached library information, and progress are local to the Chrome profile. Disconnecting removes the login; pending per-account progress is retained for reconnection.

The floating card is an isolated extension frame, with a per-tab registration. Your login tokens and authenticated audio addresses are never inserted into the webpage or included in card UI snapshots. All code is bundled locally; there are no analytics or remotely loaded scripts.

Permissions:

- **activeTab + scripting:** insert the card into the page after you click Tempo. It does not automatically scan every website.
- **storage:** save settings, login tokens, library cache, and progress.
- **offscreen:** keep audio playing independently of the card.
- **alarms:** retry pending progress while Chrome is running.
- **abs.hasbreo.com:** connect to the default ABS server. Other HTTPS servers require your optional site-access permission. HTTP is supported only for localhost development.

Audio uses the ABS-supported token query parameter inside the background audio document. That authenticated URL is not exposed to webpages. Your ABS server and reverse proxy handle those requests as they do other authenticated media requests.

## Update and troubleshoot

Keep the installed folder. To update, stop playback, extract the new ZIP, replace the files in the same folder, and click **Reload** on the Tempo card at **chrome://extensions**. Refresh webpages before reopening the card. Updates are manual.

If login fails, check the server address and your ABS credentials. Renewed logins use ABS refresh tokens when provided; an expired login may require reconnecting in Settings. Progress remains saved locally.

If playback fails, retry Play or check the server connection and audio format. Streaming requires a reachable server and a browser-supported audio codec. The first version does not transcode audio. A server sign-in wall outside ABS, such as Cloudflare Access, may need additional configuration; standard ABS username/password login is supported.

The extension's core normalisation, chapter lookup, and conservative sync decisions reuse code from the existing Tempo Web source. The full Tempo Web and its hosted configuration are unchanged.

## Verification

See **TEST-RESULTS.txt** for automated coverage and verification limits. Development sources are included as the extension's readable JS, HTML, CSS, and SVG files.

References: https://api.audiobookshelf.org/ · https://developer.chrome.com/docs/extensions/reference/api/offscreen
