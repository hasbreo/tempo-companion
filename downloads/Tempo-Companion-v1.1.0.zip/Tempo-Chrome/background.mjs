import {mountPlayer} from './player-background.mjs';
import {mountFinder} from './finder-background.mjs';
const WEB='https://tempo.hasbreo.com';
let creating=null,closing=false,lastPlayer=Date.now(),lastFinder=0,playerJobs=0,finderJobs=0;
const playerPeers=new Map();
const shared={
 async ensureWeb(){
  if(closing)await closing;
  const found=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[chrome.runtime.getURL('offscreen.html')]});if(found.length)return;
  if(!creating)creating=chrome.offscreen.createDocument({url:'offscreen.html',reasons:['AUDIO_PLAYBACK','IFRAME_SCRIPTING'],justification:'Host the existing Tempo Web player and its book-search integration while the native popup or visible Web tab is closed.'}).finally(()=>creating=null);
  await creating;
 },
 touch(kind){if(kind==='player')lastPlayer=Date.now();else lastFinder=Date.now();},
 begin(kind){shared.touch(kind);if(kind==='player')playerJobs++;else finderJobs++;},
 end(kind){if(kind==='player')playerJobs--;else finderJobs--;},
 playerState(id,state){playerPeers.set(id,state);shared.idle();},
 removePlayer(id){playerPeers.delete(id);},
 idle(){
  if(closing||creating||playerJobs||finderJobs||Date.now()-lastPlayer<30000||lastFinder&&Date.now()-lastFinder<600000)return;
  if([...playerPeers.values()].some(s=>s?.connected&&!s.paused))return;
  closing=chrome.offscreen.closeDocument().catch(()=>{}).finally(()=>closing=false);
 }
};
function popup(sender,file){return sender.id===chrome.runtime.id&&sender.url===chrome.runtime.getURL(file);}
chrome.runtime.onInstalled.addListener(()=>{chrome.contextMenus.removeAll(()=>chrome.contextMenus.create({id:'tempo-find-book',title:'Find in Tempo: “%s”',contexts:['selection']}));});
chrome.contextMenus.onClicked.addListener((info,tab)=>{
 if(info.menuItemId!=='tempo-find-book')return;const query=String(info.selectionText||'').trim().slice(0,200);if(query.length<2)return;
 chrome.storage.session.set({nextView:'finder',pendingQuery:query}).then(()=>chrome.action.openPopup(tab?.windowId!=null?{windowId:tab.windowId}:{})).catch(()=>chrome.action.setBadgeText({text:'FIND'}));
});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
 if(m.target!=='tempo-navigation'||m.type!=='entry'||!popup(sender,'popup.html'))return;
 chrome.storage.session.get(['nextView','pendingQuery']).then(async j=>{await chrome.storage.session.remove('nextView');reply({view:j.nextView==='finder'||j.pendingQuery?'finder':'player'});},()=>reply({view:'player'}));return true;
});
mountPlayer(shared);mountFinder(shared);
