// Only a context-menu launch changes the initial view. Toolbar clicks default to player.
try{const r=await chrome.runtime.sendMessage({target:'tempo-navigation',type:'entry'});window.location.replace(r?.view==='finder'?'finder.html':'player.html');}catch{window.location.replace('player.html');}
