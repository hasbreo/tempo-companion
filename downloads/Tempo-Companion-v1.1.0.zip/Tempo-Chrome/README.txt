TEMPO COMPANION — 1.1.0
One Chrome extension: a small player normally, Book Finder when requested.

INSTALL OR UPDATE
Extract this ZIP. Keep the Tempo-Chrome folder somewhere permanent.
New install: chrome://extensions > Developer mode > Load unpacked. Choose
Tempo-Chrome containing manifest.json. Pin Tempo Companion.
Existing small Tempo player: stop playback, replace the CONTENTS of the
existing installed Tempo-Chrome folder with these files, then click Reload
on its card at chrome://extensions. Keep the same installed folder path.
Disable/remove the old separate Tempo Book Finder extension if installed,
to avoid duplicate Find in Tempo menu items. Your Web sign-ins stay in Web.

Open https://tempo.hasbreo.com in the SAME Chrome profile and refresh it.
Use your existing ABS sign-in for playback and the existing ReadMeABook
connection INSIDE TEMPO WEB for book/release search. No extension login.
Enable Remember login for each connection for use with the Web tab closed;
otherwise keep the relevant connected Tempo Web tab open.

PLAYER
A normal toolbar click opens the small 350px Tempo player.
Play/pause, skip 30 seconds, scrub within the chapter, adjust speed.
Find books opens the larger 560x590px search view only when you want it.
Closing the popup or switching views does not stop playback.

BOOK FINDER
Highlight a title on a webpage > right-click Find in Tempo. The larger
Finder popup opens directly. You can also enter a title or author there.
Choose the book, compare release results, edit the release search title,
sort/filter results, then Get this release > Confirm download.
The chosen release uses Tempo Web's EXISTING search/download integration.
The Player button returns to the small player, even during a slow search.
A fresh normal toolbar click opens the small player again.

BACKGROUND & SYNC
One shared background Web connection serves both views. Audio continues
while Chrome runs. Closing Chrome stops audio, but a download already
accepted by your server continues there. Search results last while the
connection stays alive. An idle, nonplaying connection can close after
about ten minutes after using Finder (about 30 seconds for player-only
use); search again if it reconnects. Active audio/searches protect it.
Playback positions and conflicts use Tempo Web's existing logic.

If a download send is uncertain, check server downloads inside Tempo Web
before retrying. Download writes are not automatically retried.

PERMISSIONS & PRIVACY
Only tempo.hasbreo.com access; context-menu selection; offscreen hosting;
local/session storage. Other webpages are not scanned. Only text you
choose through Find in Tempo becomes a search query. Covers can load from
HTTPS artwork hosts without referring page URLs. Extension storage does
not copy Web passwords or login tokens. The embedded Web application uses
its own existing sign-in storage and connected servers.

Privacy: https://hasbreo.com/privacy/extensions/tempo-companion
Guide: https://hasbreo.com/tempo/chrome

TESTING
Automated checks cover routing, one shared document, player controls while
searching, playback handoff, both popup DOMs, search/filter/confirmation,
message validation and account-change handling without audio-page reload.
Native installed-extension behavior and real account/download testing
still need confirmation in desktop Chrome. No live download was started.
