export function mountFinder(shared){
const WEB='https://tempo.hasbreo.com',peers=new Map(),requests=new Map(),wait=ms=>new Promise(r=>setTimeout(r,ms));
let selected=null,state=null,busy='';
const loaded=chrome.storage.session.get('finderState').then(j=>{if(!state)state=j.finderState||null;});
const save=()=>chrome.storage.session.set({finderState:state}).catch(()=>{});
const valid=sender=>{try{return sender.id===chrome.runtime.id&&new URL(sender.url).origin===WEB;}catch{return false;}};
function pick(){const all=[...peers.values()];return all.find(p=>p.id===selected&&p.state?.connected)||all.find(p=>p.tabId!==null&&p.state?.connected)||all.find(p=>p.state?.connected)||all.find(p=>p.state)||null;}
const ensureWeb=()=>shared.ensureWeb();
async function ready(){let p=pick();if(p?.state.connected)return p;await ensureWeb();for(let i=0;i<225;i++){p=pick();if(p?.state.connected)return p;const b=[...peers.values()].find(p=>p.tabId===null&&p.state);if(b)return b;await wait(200);}if(p)return p;throw Error('Tempo is taking a while to connect. Open Tempo Web, refresh it, then try again.');}
function command(peer,name,args){const id=crypto.randomUUID();return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{requests.delete(id);reject(Error(name==='confirm'?'The server may have received your selection. Check server downloads in Tempo Web before trying again.':'Tempo took too long to respond. Please try the search again.'));},145000);requests.set(id,{peer:peer.id,resolve,reject,timer});try{peer.port.postMessage({type:'command',id,command:name,args});}catch(e){clearTimeout(timer);requests.delete(id);reject(e);}});}
chrome.runtime.onConnect.addListener(port=>{
 if(port.name!=='tempo-finder-web'||!valid(port.sender))return;
 const id=crypto.randomUUID(),p={id,port,tabId:port.sender.tab?.id??null,state:null};peers.set(id,p);
 port.onMessage.addListener(m=>{
  if(m.type==='state'&&m.state){p.state=m.state;if(!selected||selected===id){selected=id;state=m.state;save();}}
  if(m.type==='reply'){const r=requests.get(m.id);if(!r||r.peer!==id)return;clearTimeout(r.timer);requests.delete(m.id);if(m.state){p.state=m.state;state=m.state;selected=id;save();}m.error?r.reject(Error(m.error)):r.resolve(m.state);}
  shared.idle();
 });
 port.onDisconnect.addListener(()=>{peers.delete(id);for(const [rid,r]of requests)if(r.peer===id){clearTimeout(r.timer);r.reject(Error('Tempo reconnected. If you were downloading, check server downloads before trying again.'));requests.delete(rid);}if(selected===id){selected=null;state=null;save();}});
});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
 if(m.target!=='tempo-finder'||sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('finder.html'))return;
 shared.touch('finder');
 const run=async()=>{
  await loaded;
  if(m.type==='bootstrap'){const j=await chrome.storage.session.get('pendingQuery');await chrome.storage.session.remove('pendingQuery');await chrome.action.setBadgeText({text:''});return {state,busy,pendingQuery:j.pendingQuery||''};}
  if(m.type==='cached')return {state,busy};
  if(m.type==='openWeb'){await chrome.tabs.create({url:WEB+'/readmeabook'});return {};}
  if(!['state','search','books','releases','prepare','cancel','confirm','tracking'].includes(m.type))throw Error('Unsupported Tempo action.');
  if(busy)throw Error('Tempo is still working. Your search will stay here when you reopen the popup.');
  busy=m.type;shared.begin('finder');
  try{const p=await ready();selected=p.id;state=await command(p,m.type,m.args||{});await save();return {state,busy:''};}finally{busy='';shared.end('finder');}
 };
 run().then(reply,e=>reply({error:String(e.message||'Tempo could not connect.'),state,busy}));return true;
});

}
